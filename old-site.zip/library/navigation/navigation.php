<nav class="side<?=$navigationParams?>">
  <div class="navigation">
    <ul></ul>
  </div>
</nav>