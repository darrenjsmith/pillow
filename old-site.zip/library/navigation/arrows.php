<nav class="side left">
  <div class="navigation prevSlide">
    <div class="cell">
      <span class="prevSlide"><svg class="sideArrow<?=$navigationParams?>"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#arrow-left"></use></svg></span>
    </div>
  </div>
</nav>

<nav class="side">
  <div class="navigation">
    <div class="cell">
      <span class="nextSlide"><svg class="sideArrow<?=$navigationParams?>"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#arrow-right"></use></svg></span>
    </div>
  </div>
</nav>